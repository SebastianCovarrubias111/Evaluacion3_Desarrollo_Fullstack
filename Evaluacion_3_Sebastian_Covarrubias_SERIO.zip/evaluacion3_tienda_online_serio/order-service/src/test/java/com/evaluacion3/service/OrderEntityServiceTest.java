package com.evaluacion3.service;
import com.evaluacion3.dto.OrderEntityRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.OrderEntityRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class OrderEntityServiceTest {
  @Mock private OrderEntityRepository repository;
  @InjectMocks private OrderEntityService service;
  @Test void shouldFailValidation(){
    OrderEntityRequest request = new OrderEntityRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
