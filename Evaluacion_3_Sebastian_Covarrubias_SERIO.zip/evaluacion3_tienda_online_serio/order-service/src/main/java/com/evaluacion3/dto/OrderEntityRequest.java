package com.evaluacion3.dto;
    public class OrderEntityRequest {
private Long customerId;
private Long productId;
private Integer quantity;
private Double total;
private String status;
public Long getCustomerId() { return customerId; }
public void setCustomerId(Long customerId) { this.customerId = customerId; }
public Long getProductId() { return productId; }
public void setProductId(Long productId) { this.productId = productId; }
public Integer getQuantity() { return quantity; }
public void setQuantity(Integer quantity) { this.quantity = quantity; }
public Double getTotal() { return total; }
public void setTotal(Double total) { this.total = total; }
public String getStatus() { return status; }
public void setStatus(String status) { this.status = status; }
    }
