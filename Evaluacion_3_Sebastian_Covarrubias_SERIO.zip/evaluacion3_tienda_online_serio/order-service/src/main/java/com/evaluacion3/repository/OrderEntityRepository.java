package com.evaluacion3.repository;
import com.evaluacion3.model.OrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface OrderEntityRepository extends JpaRepository<OrderEntity, Long> {

}
