package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.OrderEntityService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/orders")
public class OrderEntityController {
  private final OrderEntityService service;
  public OrderEntityController(OrderEntityService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<OrderEntityResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public OrderEntityResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public OrderEntityResponse create(@RequestBody OrderEntityRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "order-service OK"; }

}
