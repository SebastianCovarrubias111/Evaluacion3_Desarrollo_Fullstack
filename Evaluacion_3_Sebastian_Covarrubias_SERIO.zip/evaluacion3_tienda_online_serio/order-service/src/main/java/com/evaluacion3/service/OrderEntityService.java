package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.OrderEntity; import com.evaluacion3.repository.OrderEntityRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class OrderEntityService {
  private final OrderEntityRepository repository;
  public OrderEntityService(OrderEntityRepository repository){ this.repository=repository; }
  public List<OrderEntityResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public OrderEntityResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public OrderEntityResponse create(OrderEntityRequest request){
    if (request.getQuantity() == null || request.getQuantity() <= 0) throw new BusinessException("La cantidad debe ser mayor a 0");
    OrderEntity entity = new OrderEntity();
entity.setCustomerId(request.getCustomerId());
entity.setProductId(request.getProductId());
entity.setQuantity(request.getQuantity());
entity.setTotal(request.getTotal());
entity.setStatus(request.getStatus());
    return toResponse(repository.save(entity));
  }
  private OrderEntityResponse toResponse(OrderEntity entity){
    OrderEntityResponse response = new OrderEntityResponse();
    response.setId(entity.getId());
response.setCustomerId(entity.getCustomerId());
response.setProductId(entity.getProductId());
response.setQuantity(entity.getQuantity());
response.setTotal(entity.getTotal());
response.setStatus(entity.getStatus());
    return response;
  }

}
