package com.evaluacion3.service;
import com.evaluacion3.dto.PaymentRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.PaymentRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
  @Mock private PaymentRepository repository;
  @InjectMocks private PaymentService service;
  @Test void shouldFailValidation(){
    PaymentRequest request = new PaymentRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
