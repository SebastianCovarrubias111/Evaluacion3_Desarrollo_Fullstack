package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Payment; import com.evaluacion3.repository.PaymentRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class PaymentService {
  private final PaymentRepository repository;
  public PaymentService(PaymentRepository repository){ this.repository=repository; }
  public List<PaymentResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public PaymentResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public PaymentResponse create(PaymentRequest request){
    if (request.getAmount() == null || request.getAmount() <= 0) throw new BusinessException("El monto debe ser mayor a 0");
    Payment entity = new Payment();
entity.setOrderId(request.getOrderId());
entity.setAmount(request.getAmount());
entity.setStatus(request.getStatus());
    return toResponse(repository.save(entity));
  }
  private PaymentResponse toResponse(Payment entity){
    PaymentResponse response = new PaymentResponse();
    response.setId(entity.getId());
response.setOrderId(entity.getOrderId());
response.setAmount(entity.getAmount());
response.setStatus(entity.getStatus());
    return response;
  }

}
