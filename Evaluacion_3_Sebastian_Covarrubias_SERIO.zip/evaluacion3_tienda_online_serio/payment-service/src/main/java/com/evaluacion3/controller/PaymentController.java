package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.PaymentService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/payments")
public class PaymentController {
  private final PaymentService service;
  public PaymentController(PaymentService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<PaymentResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public PaymentResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public PaymentResponse create(@RequestBody PaymentRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "payment-service OK"; }

}
