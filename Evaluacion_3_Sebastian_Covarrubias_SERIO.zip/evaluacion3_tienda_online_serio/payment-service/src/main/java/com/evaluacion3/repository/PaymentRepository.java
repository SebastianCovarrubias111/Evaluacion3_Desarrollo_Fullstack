package com.evaluacion3.repository;
import com.evaluacion3.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PaymentRepository extends JpaRepository<Payment, Long> {

}
