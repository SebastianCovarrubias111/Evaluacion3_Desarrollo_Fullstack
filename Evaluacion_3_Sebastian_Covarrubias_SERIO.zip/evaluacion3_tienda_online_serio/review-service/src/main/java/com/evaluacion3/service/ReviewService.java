package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Review; import com.evaluacion3.repository.ReviewRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class ReviewService {
  private final ReviewRepository repository;
  public ReviewService(ReviewRepository repository){ this.repository=repository; }
  public List<ReviewResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public ReviewResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public ReviewResponse create(ReviewRequest request){
    if (request.getRating() == null || request.getRating() < 1 || request.getRating() > 5) throw new BusinessException("El rating debe estar entre 1 y 5");
    Review entity = new Review();
entity.setProductId(request.getProductId());
entity.setComment(request.getComment());
entity.setRating(request.getRating());
    return toResponse(repository.save(entity));
  }
  private ReviewResponse toResponse(Review entity){
    ReviewResponse response = new ReviewResponse();
    response.setId(entity.getId());
response.setProductId(entity.getProductId());
response.setComment(entity.getComment());
response.setRating(entity.getRating());
    return response;
  }

}
