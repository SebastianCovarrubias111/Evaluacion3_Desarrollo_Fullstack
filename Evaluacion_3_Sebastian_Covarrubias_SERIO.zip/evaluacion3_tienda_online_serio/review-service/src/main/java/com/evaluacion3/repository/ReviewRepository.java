package com.evaluacion3.repository;
import com.evaluacion3.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ReviewRepository extends JpaRepository<Review, Long> {

}
