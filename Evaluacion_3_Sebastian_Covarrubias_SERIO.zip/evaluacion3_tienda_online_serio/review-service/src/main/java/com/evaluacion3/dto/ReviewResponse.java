package com.evaluacion3.dto;
    public class ReviewResponse {
private Long id;
private Long productId;
private String comment;
private Integer rating;
public Long getId() { return id; }
public void setId(Long id) { this.id = id; }
public Long getProductId() { return productId; }
public void setProductId(Long productId) { this.productId = productId; }
public String getComment() { return comment; }
public void setComment(String comment) { this.comment = comment; }
public Integer getRating() { return rating; }
public void setRating(Integer rating) { this.rating = rating; }
    }
