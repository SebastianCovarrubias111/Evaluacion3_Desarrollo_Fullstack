package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.ReviewService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/reviews")
public class ReviewController {
  private final ReviewService service;
  public ReviewController(ReviewService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<ReviewResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public ReviewResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public ReviewResponse create(@RequestBody ReviewRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "review-service OK"; }

}
