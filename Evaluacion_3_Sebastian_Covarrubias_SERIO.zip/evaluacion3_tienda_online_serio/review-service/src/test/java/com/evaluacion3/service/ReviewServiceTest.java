package com.evaluacion3.service;
import com.evaluacion3.dto.ReviewRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.ReviewRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class ReviewServiceTest {
  @Mock private ReviewRepository repository;
  @InjectMocks private ReviewService service;
  @Test void shouldFailValidation(){
    ReviewRequest request = new ReviewRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
