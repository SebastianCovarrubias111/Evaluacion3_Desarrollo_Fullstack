package com.evaluacion3.repository;
import com.evaluacion3.model.InventoryItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long> {
    java.util.Optional<InventoryItem> findByProductId(Long productId);
}
