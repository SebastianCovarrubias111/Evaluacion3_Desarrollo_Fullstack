package com.evaluacion3.dto;
    public class InventoryItemResponse {
private Long id;
private Long productId;
private Integer stock;
public Long getId() { return id; }
public void setId(Long id) { this.id = id; }
public Long getProductId() { return productId; }
public void setProductId(Long productId) { this.productId = productId; }
public Integer getStock() { return stock; }
public void setStock(Integer stock) { this.stock = stock; }
    }
