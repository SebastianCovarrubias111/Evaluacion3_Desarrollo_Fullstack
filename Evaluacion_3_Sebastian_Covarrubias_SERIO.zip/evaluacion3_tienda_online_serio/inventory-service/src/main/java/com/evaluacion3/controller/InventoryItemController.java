package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.InventoryItemService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/inventory")
public class InventoryItemController {
  private final InventoryItemService service;
  public InventoryItemController(InventoryItemService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<InventoryItemResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public InventoryItemResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public InventoryItemResponse create(@RequestBody InventoryItemRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "inventory-service OK"; }
  @GetMapping("/product/{productId}") public com.evaluacion3.model.InventoryItem getByProductId(@PathVariable Long productId){ return service.findByProductId(productId); }
}
