package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.InventoryItem; import com.evaluacion3.repository.InventoryItemRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class InventoryItemService {
  private final InventoryItemRepository repository;
  public InventoryItemService(InventoryItemRepository repository){ this.repository=repository; }
  public List<InventoryItemResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public InventoryItemResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public InventoryItemResponse create(InventoryItemRequest request){
    if (request.getStock() == null || request.getStock() < 0) throw new BusinessException("El stock no puede ser negativo");
    InventoryItem entity = new InventoryItem();
entity.setProductId(request.getProductId());
entity.setStock(request.getStock());
    return toResponse(repository.save(entity));
  }
  private InventoryItemResponse toResponse(InventoryItem entity){
    InventoryItemResponse response = new InventoryItemResponse();
    response.setId(entity.getId());
response.setProductId(entity.getProductId());
response.setStock(entity.getStock());
    return response;
  }
  public com.evaluacion3.model.InventoryItem findByProductId(Long productId){ return repository.findByProductId(productId).orElseThrow(() -> new ResourceNotFoundException("No existe inventario para producto "+productId)); }
}
