package com.evaluacion3.model;
    import jakarta.persistence.*;
    @Entity
    public class InventoryItem {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
private Long productId;
private Integer stock;
public Long getId() { return id; }
public void setId(Long id) { this.id = id; }
public Long getProductId() { return productId; }
public void setProductId(Long productId) { this.productId = productId; }
public Integer getStock() { return stock; }
public void setStock(Integer stock) { this.stock = stock; }
    }
