package com.evaluacion3.dto;
    public class InventoryItemRequest {
private Long productId;
private Integer stock;
public Long getProductId() { return productId; }
public void setProductId(Long productId) { this.productId = productId; }
public Integer getStock() { return stock; }
public void setStock(Integer stock) { this.stock = stock; }
    }
