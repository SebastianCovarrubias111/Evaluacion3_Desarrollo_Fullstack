package com.evaluacion3.service;
import com.evaluacion3.dto.InventoryItemRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.InventoryItemRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class InventoryItemServiceTest {
  @Mock private InventoryItemRepository repository;
  @InjectMocks private InventoryItemService service;
  @Test void shouldFailValidation(){
    InventoryItemRequest request = new InventoryItemRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
