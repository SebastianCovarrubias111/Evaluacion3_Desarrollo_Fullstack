package com.evaluacion3.service;
import com.evaluacion3.dto.CustomerRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.CustomerRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {
  @Mock private CustomerRepository repository;
  @InjectMocks private CustomerService service;
  @Test void shouldFailValidation(){
    CustomerRequest request = new CustomerRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
