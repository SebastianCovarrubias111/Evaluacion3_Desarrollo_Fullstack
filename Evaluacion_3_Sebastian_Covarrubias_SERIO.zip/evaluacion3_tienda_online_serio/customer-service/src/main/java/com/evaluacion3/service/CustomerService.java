package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Customer; import com.evaluacion3.repository.CustomerRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class CustomerService {
  private final CustomerRepository repository;
  public CustomerService(CustomerRepository repository){ this.repository=repository; }
  public List<CustomerResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public CustomerResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public CustomerResponse create(CustomerRequest request){
    if (request.getEmail() == null || request.getEmail().isBlank()) throw new BusinessException("El email es obligatorio");
    Customer entity = new Customer();
entity.setName(request.getName());
entity.setEmail(request.getEmail());
    return toResponse(repository.save(entity));
  }
  private CustomerResponse toResponse(Customer entity){
    CustomerResponse response = new CustomerResponse();
    response.setId(entity.getId());
response.setName(entity.getName());
response.setEmail(entity.getEmail());
    return response;
  }

}
