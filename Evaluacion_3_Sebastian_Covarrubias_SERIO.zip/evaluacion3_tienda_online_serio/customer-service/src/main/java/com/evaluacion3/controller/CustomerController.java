package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.CustomerService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/customers")
public class CustomerController {
  private final CustomerService service;
  public CustomerController(CustomerService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<CustomerResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public CustomerResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public CustomerResponse create(@RequestBody CustomerRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "customer-service OK"; }

}
