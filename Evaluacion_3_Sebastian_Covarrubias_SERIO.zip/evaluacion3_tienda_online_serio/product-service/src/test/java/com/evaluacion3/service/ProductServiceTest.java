package com.evaluacion3.service;
import com.evaluacion3.dto.ProductRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.ProductRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class ProductServiceTest {
  @Mock private ProductRepository repository;
  @InjectMocks private ProductService service;
  @Test void shouldFailValidation(){
    ProductRequest request = new ProductRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
