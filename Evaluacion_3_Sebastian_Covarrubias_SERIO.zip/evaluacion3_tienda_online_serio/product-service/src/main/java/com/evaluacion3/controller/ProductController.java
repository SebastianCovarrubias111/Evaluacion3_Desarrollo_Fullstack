package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.ProductService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/products")
public class ProductController {
  private final ProductService service;
  public ProductController(ProductService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<ProductResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public ProductResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public ProductResponse create(@RequestBody ProductRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "product-service OK"; }

}
