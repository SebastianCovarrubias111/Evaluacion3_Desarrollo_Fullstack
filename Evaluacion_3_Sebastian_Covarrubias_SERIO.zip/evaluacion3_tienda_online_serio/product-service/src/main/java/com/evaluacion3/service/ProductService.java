package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Product; import com.evaluacion3.repository.ProductRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class ProductService {
  private final ProductRepository repository;
  public ProductService(ProductRepository repository){ this.repository=repository; }
  public List<ProductResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public ProductResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public ProductResponse create(ProductRequest request){
    if (request.getPrice() == null || request.getPrice() <= 0) throw new BusinessException("El precio debe ser mayor a 0");
    Product entity = new Product();
entity.setName(request.getName());
entity.setPrice(request.getPrice());
    return toResponse(repository.save(entity));
  }
  private ProductResponse toResponse(Product entity){
    ProductResponse response = new ProductResponse();
    response.setId(entity.getId());
response.setName(entity.getName());
response.setPrice(entity.getPrice());
    return response;
  }

}
