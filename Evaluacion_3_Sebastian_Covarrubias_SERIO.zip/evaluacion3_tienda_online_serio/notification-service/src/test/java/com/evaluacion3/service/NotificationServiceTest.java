package com.evaluacion3.service;
import com.evaluacion3.dto.NotificationRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.NotificationRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {
  @Mock private NotificationRepository repository;
  @InjectMocks private NotificationService service;
  @Test void shouldFailValidation(){
    NotificationRequest request = new NotificationRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
