package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Notification; import com.evaluacion3.repository.NotificationRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class NotificationService {
  private final NotificationRepository repository;
  public NotificationService(NotificationRepository repository){ this.repository=repository; }
  public List<NotificationResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public NotificationResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public NotificationResponse create(NotificationRequest request){
    if (request.getMessage() == null || request.getMessage().isBlank()) throw new BusinessException("El mensaje es obligatorio");
    Notification entity = new Notification();
entity.setCustomerId(request.getCustomerId());
entity.setMessage(request.getMessage());
    return toResponse(repository.save(entity));
  }
  private NotificationResponse toResponse(Notification entity){
    NotificationResponse response = new NotificationResponse();
    response.setId(entity.getId());
response.setCustomerId(entity.getCustomerId());
response.setMessage(entity.getMessage());
    return response;
  }

}
