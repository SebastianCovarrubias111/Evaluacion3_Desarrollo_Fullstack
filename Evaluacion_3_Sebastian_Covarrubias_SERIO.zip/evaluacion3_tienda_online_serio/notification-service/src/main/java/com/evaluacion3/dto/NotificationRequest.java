package com.evaluacion3.dto;
    public class NotificationRequest {
private Long customerId;
private String message;
public Long getCustomerId() { return customerId; }
public void setCustomerId(Long customerId) { this.customerId = customerId; }
public String getMessage() { return message; }
public void setMessage(String message) { this.message = message; }
    }
