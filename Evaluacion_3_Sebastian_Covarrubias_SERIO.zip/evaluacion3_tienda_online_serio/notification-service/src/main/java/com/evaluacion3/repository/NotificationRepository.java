package com.evaluacion3.repository;
import com.evaluacion3.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
public interface NotificationRepository extends JpaRepository<Notification, Long> {

}
