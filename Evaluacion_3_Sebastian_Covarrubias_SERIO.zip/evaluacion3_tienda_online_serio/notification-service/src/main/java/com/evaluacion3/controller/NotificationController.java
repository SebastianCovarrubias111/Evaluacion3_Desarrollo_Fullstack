package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.NotificationService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
  private final NotificationService service;
  public NotificationController(NotificationService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<NotificationResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public NotificationResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public NotificationResponse create(@RequestBody NotificationRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "notification-service OK"; }

}
