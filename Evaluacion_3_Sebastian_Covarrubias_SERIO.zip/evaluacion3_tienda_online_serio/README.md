# Evaluacion 3 Sebastian Covarrubias - Tienda Online Distribuida

Proyecto con 10 microservicios, API Gateway, DTOs, reglas de negocio, Swagger, tests con Mockito y estructura para IntelliJ IDEA.

## Microservicios
- gateway-service (8080)
- customer-service (8081)
- product-service (8082)
- inventory-service (8083)
- cart-service (8084)
- order-service (8085)
- payment-service (8086)
- shipping-service (8087)
- notification-service (8088)
- review-service (8089)

## Flujo
customer/product/inventory/cart -> order -> payment -> shipping -> notification + review

## Defensa
- Explicar patrón Controller/Service/Repository
- Mostrar DTOs
- Mostrar reglas de negocio:
  - precio > 0
  - stock no negativo
  - quantity > 0
  - rating 1-5
- Mostrar Gateway
- Mostrar Swagger y tests Mockito
