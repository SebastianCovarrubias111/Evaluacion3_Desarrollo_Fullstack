package com.evaluacion3.service;
import com.evaluacion3.dto.ShipmentRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.ShipmentRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class ShipmentServiceTest {
  @Mock private ShipmentRepository repository;
  @InjectMocks private ShipmentService service;
  @Test void shouldFailValidation(){
    ShipmentRequest request = new ShipmentRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
