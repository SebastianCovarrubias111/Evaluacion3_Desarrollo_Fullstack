package com.evaluacion3.dto;
    public class ShipmentRequest {
private Long orderId;
private String address;
private String status;
public Long getOrderId() { return orderId; }
public void setOrderId(Long orderId) { this.orderId = orderId; }
public String getAddress() { return address; }
public void setAddress(String address) { this.address = address; }
public String getStatus() { return status; }
public void setStatus(String status) { this.status = status; }
    }
