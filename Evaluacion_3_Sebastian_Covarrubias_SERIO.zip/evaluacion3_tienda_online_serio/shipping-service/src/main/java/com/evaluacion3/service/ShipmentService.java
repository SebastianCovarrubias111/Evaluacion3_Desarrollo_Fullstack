package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.Shipment; import com.evaluacion3.repository.ShipmentRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class ShipmentService {
  private final ShipmentRepository repository;
  public ShipmentService(ShipmentRepository repository){ this.repository=repository; }
  public List<ShipmentResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public ShipmentResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public ShipmentResponse create(ShipmentRequest request){
    if (request.getAddress() == null || request.getAddress().isBlank()) throw new BusinessException("La dirección es obligatoria");
    Shipment entity = new Shipment();
entity.setOrderId(request.getOrderId());
entity.setAddress(request.getAddress());
entity.setStatus(request.getStatus());
    return toResponse(repository.save(entity));
  }
  private ShipmentResponse toResponse(Shipment entity){
    ShipmentResponse response = new ShipmentResponse();
    response.setId(entity.getId());
response.setOrderId(entity.getOrderId());
response.setAddress(entity.getAddress());
response.setStatus(entity.getStatus());
    return response;
  }

}
