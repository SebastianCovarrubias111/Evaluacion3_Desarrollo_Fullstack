package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.ShipmentService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/shipping")
public class ShipmentController {
  private final ShipmentService service;
  public ShipmentController(ShipmentService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<ShipmentResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public ShipmentResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public ShipmentResponse create(@RequestBody ShipmentRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "shipping-service OK"; }

}
