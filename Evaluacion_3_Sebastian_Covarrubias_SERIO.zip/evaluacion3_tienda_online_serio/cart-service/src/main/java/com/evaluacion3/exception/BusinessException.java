package com.evaluacion3.exception;
public class BusinessException extends RuntimeException { public BusinessException(String m){ super(m);} }
