package com.evaluacion3.exception;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.Map;
@RestControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler(ResourceNotFoundException.class) public ResponseEntity<Map<String,String>> nf(ResourceNotFoundException ex){ return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error",ex.getMessage()));}
  @ExceptionHandler(BusinessException.class) public ResponseEntity<Map<String,String>> be(BusinessException ex){ return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error",ex.getMessage()));}
}
