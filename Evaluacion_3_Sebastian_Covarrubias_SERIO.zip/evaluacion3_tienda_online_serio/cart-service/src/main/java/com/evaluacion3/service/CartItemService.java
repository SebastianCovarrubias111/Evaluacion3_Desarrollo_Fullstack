package com.evaluacion3.service;
import com.evaluacion3.dto.*; import com.evaluacion3.exception.*; import com.evaluacion3.model.CartItem; import com.evaluacion3.repository.CartItemRepository;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class CartItemService {
  private final CartItemRepository repository;
  public CartItemService(CartItemRepository repository){ this.repository=repository; }
  public List<CartItemResponse> findAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
  public CartItemResponse findById(Long id){ return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No existe registro con id "+id))); }
  public CartItemResponse create(CartItemRequest request){
    if (request.getQuantity() == null || request.getQuantity() <= 0) throw new BusinessException("La cantidad debe ser mayor a 0");
    CartItem entity = new CartItem();
entity.setCustomerId(request.getCustomerId());
entity.setProductId(request.getProductId());
entity.setQuantity(request.getQuantity());
    return toResponse(repository.save(entity));
  }
  private CartItemResponse toResponse(CartItem entity){
    CartItemResponse response = new CartItemResponse();
    response.setId(entity.getId());
response.setCustomerId(entity.getCustomerId());
response.setProductId(entity.getProductId());
response.setQuantity(entity.getQuantity());
    return response;
  }

}
