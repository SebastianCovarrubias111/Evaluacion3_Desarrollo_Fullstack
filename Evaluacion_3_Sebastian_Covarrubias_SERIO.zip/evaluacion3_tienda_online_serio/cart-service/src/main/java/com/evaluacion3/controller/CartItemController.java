package com.evaluacion3.controller;
import com.evaluacion3.dto.*; import com.evaluacion3.service.CartItemService; import io.swagger.v3.oas.annotations.Operation; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController
@RequestMapping("/api/cart")
public class CartItemController {
  private final CartItemService service;
  public CartItemController(CartItemService service){ this.service=service; }
  @Operation(summary="Listar") @GetMapping public List<CartItemResponse> getAll(){ return service.findAll(); }
  @Operation(summary="Buscar por id") @GetMapping("/{id}") public CartItemResponse getById(@PathVariable Long id){ return service.findById(id); }
  @Operation(summary="Crear") @PostMapping public CartItemResponse create(@RequestBody CartItemRequest request){ return service.create(request); }
  @GetMapping("/health") public String health(){ return "cart-service OK"; }

}
