package com.evaluacion3.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m){ super(m);} }
