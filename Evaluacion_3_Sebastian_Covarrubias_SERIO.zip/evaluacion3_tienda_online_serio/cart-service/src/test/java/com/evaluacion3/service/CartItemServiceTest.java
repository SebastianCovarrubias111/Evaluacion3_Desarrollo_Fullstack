package com.evaluacion3.service;
import com.evaluacion3.dto.CartItemRequest;
import com.evaluacion3.exception.BusinessException;
import com.evaluacion3.repository.CartItemRepository;
import org.junit.jupiter.api.Test; import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks; import org.mockito.Mock; import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class CartItemServiceTest {
  @Mock private CartItemRepository repository;
  @InjectMocks private CartItemService service;
  @Test void shouldFailValidation(){
    CartItemRequest request = new CartItemRequest();
    assertThrows(BusinessException.class, () -> service.create(request));
  }
}
